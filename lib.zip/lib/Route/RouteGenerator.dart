
// import 'package:agva_app/Screens/Common/NotificationScreen.dart';
// import 'package:flutter/material.dart';

// class RouteGenerator {
//   static Route<dynamic> generateRoutes(RouteSettings routeSettings) {
//     switch (routeSettings.name) {
//       case '/notifcation':
//         return MaterialPageRoute(builder: (context) => NotificationScreen(notifications: [],));

//       default:
//         return MaterialPageRoute(
//             builder: (context) => Scaffold(
//                   body: Center(
//                     child: Text("Not found $routeSettings.name"),
//                   ),
//                 ));
//     }
//   }
// }