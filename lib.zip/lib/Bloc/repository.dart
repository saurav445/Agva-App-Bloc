import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:agva_app/Bloc/models.dart';
import 'package:http/http.dart' as http;

Map<String, bool> expansionStates = {};

class PostRepository {
  String token =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiNjVkZDYzMTZhZmExMzIwYjYxNjQyODQxIiwianRpIjoiVnA2a2NFZzdrOCIsImlhdCI6MTcxMjcyMzQwMywiZXhwIjoxNzE0MDE5NDAzfQ.vyJiJCDFpO2-dRvRarvQOKDmlPNnIZ1KvRjPN1V8zmo';
  Future<List<PostModel>> fetchPost() async {
    try {
      final response = await http.get(
          Uri.parse(
              'http://192.168.2.1:8000/hospital/get-access-hospital-list'),
          headers: {
            "Authorization": 'Bearer $token',
          });

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        final data = body['data'];
        print(data);

        // var hospital = data.item.body;

        //               data.forEach((hospital) {
        //         expansionStates[hospital] = false;

        //       });

        return (data as List<dynamic>).map((e) {
          return PostModel(
            title: e['Hospital_Name'],
            body: e['City'],
          );
        }).toList();
      } else {
        print(response.statusCode);
      }
    } on SocketException {
      throw Exception('Eroor while fetching data');
    } on TimeoutException {}
    throw Exception('error while fetching');
  }
}
