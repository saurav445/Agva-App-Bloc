class PostModel {
  
  String? title;
  String? body;

  PostModel({ this.title, this.body});

  PostModel.fromJson(Map<String, dynamic> json) {
   
    title = json['Hospital_Name'];
    body = json['City'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    
    data['title'] = this.title;
    data['body'] = this.body;
    return data;
  }
}